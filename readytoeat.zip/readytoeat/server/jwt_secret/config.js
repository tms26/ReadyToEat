module.exports = {
    secret: "supersecret" 
};