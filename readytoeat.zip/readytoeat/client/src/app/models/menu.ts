export class Menu {
  constructor(
    public name: string,
    public image: string,
    public createdBy: string, 
  ) {}
}