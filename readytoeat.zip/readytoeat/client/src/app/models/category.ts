export class Category {
  constructor(public name: string, public createdAt: Date) {}
}
